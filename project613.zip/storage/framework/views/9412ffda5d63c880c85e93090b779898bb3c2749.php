<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Aset')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class=" bg-gray-200 pt-8 pb-8">
        <div class="container relative">
            <div class="self-end px-2 text-right mb-2">
                <p class="text-xs">untuk nama pemindah gunakan nomor HP pemindah </p>
            </div>
            
            <div class="flex flex-wrap">
                <div class="w-full self-center px-4 lg:w-1/2">
                    <h1 class="text-2xl font-bold mb-2 mr-3">List History</h1>
                </div>
                <div class="self-end px-2 lg:w-1/2">
                    <form action="<?php echo e(route('histories.index')); ?>" class="mb-3 flex">
                        <input type="text" placeholder="Search ..." name=search class="placeholder:italic placeholder:text-slate-400 block bg-white w-full border border-slate-300 rounded-md py-2 pl-9 pr-3 shadow-sm focus:outline-none focus:border-sky-500 focus:ring-sky-500 focus:ring-1 sm:text-sm mr-4">
                        <button type="submit" class="bg-black text-white py-1 px-3 border border-black hover:border-white rounded">
                            search
                        </button>
                    </form>
                </div>
            </div>



            <div class="overflow-auto rounded-lg shadow hidden md:block">
                <table class="w-full" id="myTable" data-filter-control="true" data-show-search-clear-button="true">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <tr>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">ID History</th>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">ID Aset</th>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">Pemindah</th>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">Lokasi Lama</th>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">Lokasi Baru</th>
                            <th class="p-3 text-sm font-semibold tracking-wide text-left">Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="odd:bg-white even:bg-slate-100">
                            <td class="p-3 text-sm text-blue-500 font-bold "><?php echo e($item->id_history); ?></td>
                            <td><?php echo e($item->id_aset); ?></td>
                            <td><?php echo e($item->user->nama); ?></td>
                            <td><?php echo e($item->lokasi_lama); ?></td>
                            <td><?php echo e($item->lokasi_baru); ?></td>
                            
                            <td>
                                <?php if($item->jenis_pindah === "PINDAH"): ?>
                                <span class=" text-white font-semibold  py-1 px-3 border bg-blue-500 border-blue-500 rounded mb-1"><?php echo e($item->jenis_pindah); ?>

                                </span>
                                <?php else: ?>
                                <span class="bg-red-500 text-white font-semibold  py-1 px-6 border border-red-500 rounded mb-1"><?php echo e($item->jenis_pindah); ?>

                                </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

                <!-- small -->
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
            <div class="grid grid-cols-1 gap-4 md:hidden">
                <div class="bg-white p-4 rounded-lg shadow mb-5">
                    <div class= "flex justify-center space-x-2 text-sm">
                        <div class="p-3 text-sm text-blue-700 font-bold text-center "><?php echo e($item->id_history); ?></div>
                        <div class=" font-semibold p-3 text-sm text-black text-center"><?php echo e($item->id_aset); ?></div>
                    </div>

                    <div class="flex justify-center items-center text-sm text-center">
                        <div class=" font-semibold p-3 text-sm text-black text-center"><?php echo e($item->user->nama); ?></div>
                    </div>

                    <div class="flex justify-center items-center text-sm text-center">
                        <div class=" font-semibold p-3 text-sm text-black text-center"><?php echo e($item->lokasi_lama); ?></div>
                    </div>

                    <div class="flex justify-center items-center space-x-2 text-sm">
                        <div class=" font-semibold p-3 text-sm text-black"><?php echo e($item->lokasi_baru); ?></div>
                    </div>

                    <div class="flex items-center space-x-2 text-sm justify-center">
                        <div class="text-sm text-black">
                            <?php if($item->jenis_pindah === "PINDAH"): ?>
                            <div class="bg-blue-500  text-white font-semibold  py-1 px-3 border border-blue-500 rounded">
                                <?php echo e($item->jenis_pindah); ?>

                            </div>
                            <?php else: ?>
                                <div class="bg-red-500  text-white font-semibold  py-1 px-6 border border-red-500 rounded"><?php echo e($item->jenis_pindah); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>     
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            <!-- small stop -->
            <p class="pt-4"></p>
            <?php echo e($items->links()); ?>

        </div>
    </section>
    <script src="<?php echo e(asset('js/roy.js')); ?>"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Yudi\UNIKA\6\Workshop\project613\resources\views\asets\history.blade.php ENDPATH**/ ?>