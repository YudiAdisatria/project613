<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Lain - Lain')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section class="pt-8 pb-8 bg-gray-200">
        <div class="flex flex-wrap justify-center">
            <div class="w-full px-4 lg:w-1/2 xl:w-1/3">
                <div class="bg-blue-600 rounded-xl shadow-lg overflow-hidden mb-10">
                    <div class="py-8 px-6">
                        <h3 class="mb-3 font-bold text-xl text-white text-center">Histori Aset</h3>
                        <p class="tracking-tight font-medium text-base text-white mb-6 text-justify">Melihat histori pergerakan aset</p>
                        <p class="text-center"><a href="<?php echo e(route('histories.index')); ?>" class="items-center font-bold text-sm text-dark bg-teal-300 py-2 px-4 rounded-lg hover:opacity-80 mr-50">Lihat Disini</a></p>
                    </div>
                </div>
            </div>

            <!-- <div class="w-full px-4 lg:w-1/2 xl:w-1/3">
                <div class="bg-blue-600 rounded-xl shadow-lg overflow-hidden mb-10">
                    <div class="py-8 px-6">
                        <h3 class="mb-3 font-semibold text-xl text-white text-center">Laporan Ruangan</h3>
                        <p class="tracking-tight font-medium text-base text-white mb-6 text-justify">Terdapat di dalam menu ruangan di bawah search</p>
                        <p class="text-center"><a href="pindah_web.html" class="items-center font-bold text-sm text-dark bg-teal-300 py-2 px-4 rounded-lg hover:opacity-80 mr-50">Laporan Ruangan</a></p>
                    </div>
                </div>
            </div> -->

        </div>
        <div class="w-full pt-10 border-t border-black"></div>
        <p class="text-center justify-center mb-2 font-bold" for="tanggal">Pilih Bulan laporan untuk History Perpindahan :</p>
        <!-- Filter Report -->
      
            <!-- Filter History -->
            <form action="<?php echo e(route('histories.export')); ?>" class="mb-5">
                <div class="text-center justify-center items-center mb-2">
                    <input type="month" id="tanggal" name="tanggal" min="2018-03" class="mr-2">
                </div>

                <div class="justify-center items-center text-center">
                    <button type="submit" class="bg-black text-white py-1 px-3 border border-black hover:border-white rounded">
                        Laporan Perpindahan
                    </button>
                </div>
            </form>

        <div class="w-full pt-10 border-t border-black"></div>
            <!-- Filter List Aset -->
        <div>
            <p class="text-center justify-center mb-2 font-bold">Pilih filter untuk laporan aset :</p>
        </div>
        <div class="flex flex-wrap justify-center">
            <div class="overflow-auto hidden md:block">
                <div class="flex flex-wrap">
                    <div class="w-full self-center px-4 lg:w-1/2">
                    </div>
                </div>
                <form action="<?php echo e(route('ruangans.export')); ?>" class="flex flex-wrap mb-5">
                    
                    <select name="id_kategori" class=" mr-20 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                        <option value="" selected>Kategori</option>
                        <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($kat->id_kategori); ?>"><?php echo e($kat->nama_kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>tidak ada kategori</p>
                        <?php endif; ?>
                    </select>

                    <select name="gedung" id="gedung" class="mr-20 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                        <option value="" selected>Gedung</option>
                        <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($key); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select name="ruangan" id="ruangan" class="mr-20 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                        <option value="" selected>Ruangan</option>
                    </select>

                    <select name="kondisi" class="mr-20 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                        <option value="" selected>Kondisi</option>
                        <option value="baik">Baik</option>
                        <option value="rusak">Rusak</option>
                        <option value="hilang">Hilang</option>
                    </select>

                    <button type="submit" class="bg-black text-white py-1 px-3 border border-black hover:border-white rounded">
                        Laporan Ruangan
                    </button>
                </form>
            </div>
        </div>

        <!-- filter small -->
        <div class="bg-gray-200">
            <form action="<?php echo e(route('ruangans.export')); ?>" class="mb-5">
                <div class="flex flex-wrap md:hidden">
                    <div class="w-1/2  mt-2 px-3 ">
                        <select name="id_kategori" class=" mr-24 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                            <option value="" selected>Kategori</option>
                            <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($kat->id_kategori); ?>"><?php echo e($kat->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>tidak ada kategori</p>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="w-1/2 mt-2 px-3 ">
                        <select name="gedung" id="gedung" class="mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                            <option value="" selected>Gedung</option>
                            <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($key); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="flex flex-wrap md:hidden">
                    <div class="w-1/2  mt-2 px-3 ">
                        <select name="ruangan" id="ruangan" class="mr-12 mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                            <option value="" selected>Ruangan</option>
                        </select>
                    </div>

                    <div class="w-1/2 mt-2 px-3 ">
                        <select name="kondisi" class="mb-3 md:mb-0 text-black bg-white hover:bg-gray-100 font-medium text-sm px-12 py-2.5 text-center inline-flex items-center" id="grid-last-name">
                            <option value="" selected>Kondisi</option>
                            <option value="baik">Baik</option>
                            <option value="rusak">Rusak</option>
                            <option value="hilang">Hilang</option>
                        </select>
                    </div>
                </div>  

                <div class="mt-2 px-3 justify-center items-center text-center md:hidden">
                    <button type="submit" class="bg-black text-white py-1 px-3 border border-black hover:border-white rounded justify-center items-start text-center">
                        Laporan Ruangan
                    </button>
                </div>
            </form>  
        </div> 
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Yudi\UNIKA\6\Workshop\project613\resources\views\lain\index.blade.php ENDPATH**/ ?>